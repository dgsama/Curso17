package estDatos;

/**
 * Implementación de la interfaz {@code Racional}. El tipo de dato
 * es modificable o mutable.
 * 
 * @author Pedro Hernández
 */

public class RacionalMod extends RacionalNoMod {

	/**
	 * Crea el racional 0/1
	 */
	public RacionalMod() {
		super();
	}
	
	/**
	 * Crea un racional de numerador y denominador especificados.
	 * @param n el numerador del racional
	 * @param d el denominador del racional
	 * @throws RuntimeException si el denominador es {@code 0}
	 */
	public RacionalMod(int n, int d) {
		super(n, d);
	}
	
	/**
	 * {@inheritDoc}
	 */
	public RacionalMod(Racional r) {
		// no se debe compartir la representación
		this(r.numerador(), r.denominador());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void acumula(int dato) {
		datos[this.rep][0] += dato * this.denominador();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void acumula(Racional r) {
		int mcm = mcm(this.denominador(), r.denominador());
		datos[this.rep][0] = mcm / this.denominador() * this.numerador() +
					         mcm / r.denominador() * r.numerador();
		datos[this.rep][1] = mcm;
	} 

}
