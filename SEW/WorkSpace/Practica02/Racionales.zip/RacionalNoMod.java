package estDatos;

/**
 * Implementación de la interfaz {@code Racional}. El tipo de
 * dato es no modificable o inmutable. 
 * 
 * @author Pedro Hernández
 */

public class RacionalNoMod extends AbstractRacional {

	/**
	 * Índice de la componente del array datos que contiene
	 * la información (numerador y denominador) del racional
	 */
	protected int rep;
	
	/**
	 * Se reserva espacio de memoria para INICIAL
	 * racionales(tamaño inicial del array datos)
	 */
	protected final static int INICIAL = 100;
	/**
	 * Índice de la primera posición libre del array datos
	 */
	protected static int numRacionales = 0;
	/**
	 * Array de pares de enteros (numerador y denominador)
	 */
	protected static Integer[][] datos = new Integer[INICIAL][2];

	/**
	 * Duplica la capacidad del espacio de memoria reservado
	 * para los racionales (array datos)
	 */
	private static void incrCapacidad() {
		Integer[][] temp = new Integer[2 * datos.length][2];
		System.arraycopy(datos, 0, temp, 0, datos.length);
		datos = temp;
	}
	
	/**
	 * Crea el racional 0/1
	 */
	public RacionalNoMod() {
		this(0, 1);
	}

	/**
	 * Crea un racional de numerador y denominador especificados.
	 * @param n el numerador del racional
	 * @param d el denominador del racional
	 * @throws RuntimeException si el denominador es {@code 0}
	 */
	public RacionalNoMod(int n, int d) {
		if (d == 0) {
			throw new RuntimeException("El denominador no puede ser cero");
		}
		
		if (numRacionales == datos.length) {
			incrCapacidad();
		}
		
		// se ocupa la primera componente disponible del array datos
		this.rep = numRacionales++;
		datos[this.rep][0] = d > 0 ? n : -n; // signo en el numerador
		datos[this.rep][1] = Math.abs(d);
	}

	/**
	 * Crea un racional copia del especificado
	 * @param r el racional a copiar
	 */
	public RacionalNoMod(Racional r) {
		RacionalNoMod temp;
		
		if (r instanceof RacionalNoMod) {
			// se puede y es preferible compartir la representación
			temp = (RacionalNoMod) r;
		}
		else {
			// r no es de está clase y es necesario crear otro racional
			temp = new RacionalNoMod(r.numerador(), r.denominador());
		}
		
		this.rep = temp.rep;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int numerador() {
		return datos[this.rep][0];
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int denominador() {
		return datos[this.rep][1];
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Racional suma(Racional r) {
		int mcm = mcm(this.denominador(), r.denominador());
		return new RacionalNoMod(mcm / this.denominador() * this.numerador() +
				      	   		 mcm / r.denominador() * r.numerador(),
				      	   		 mcm);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Racional reduce() {
		int mcd = mcd(this.numerador(), this.denominador());
		return new RacionalNoMod(this.numerador() / mcd,
								 this.denominador() / mcd);
	}

}
