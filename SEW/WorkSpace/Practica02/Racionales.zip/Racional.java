package estDatos;

/**
 * Esta interfaz representa los números racionales. Un
 * número racional consta de un par de números enteros
 * denominados numerador y denominador, respectivamente.
 * 
 * <p>Las operaciones básicas modificadoras de ésta interfaz
 * están implementadas por defecto como no soportadas</p>
 * 
 * @author Pedro Hernández
 */

public interface Racional {

	/**
	 * El numerador de este racional
	 * @return el numerador del racional
	 */
	int numerador();
	
	/**
	 * El denominador de este racional
	 * @return el denominador del racional
	 */
	int denominador();
	
	/**
	 * Retorna el racional suma de este racional
	 * y el racional especificado
	 * @param r el racional especificado
	 * @return el racional suma de este y del
	 * racional {@code r}
	 */
	Racional suma(Racional r);

	/**
	 * Un nuevo racional equivalente a éste e irreducible
	 * @return un racional que cumple lo siguiente: si {@code x}
	 * es el numerador de este racional e {@code y} su denominador,
	 * entonces {@code x/mcd(x, y)} y {@code y/mcd(x, y)} son el
	 * numerador y denominador, respectivamente, del nuevo racional,
	 * siendo mcd(x, y) el máximo común divisor de {@code x} e
	 * {@code y}
	 */
	Racional reduce();
	
	/**
	 * Modifica este racional sumándole el entero especificado
	 * (opcional)
	 * @param dato el entero especificado
	 * @throws UnsupportedOperationException si la operación
	 * no está soportada
	 */
	default void acumula(int dato) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Modifica este racional sumándole el racional especificado
	 * (opcional)
	 * @param r el racional especificado
	 * @throws UnsupportedOperationException si la operación
	 * no está soportada
	 */
	default void acumula(Racional r) {
		throw new UnsupportedOperationException();
	}
	
}
