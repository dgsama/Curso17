package estDatos;

public class RacionalMain {

	public static void main(String[] args) {

		System.out.print("Creando el racional r1 de tipo RacionalMod (3/4) ...");
		Racional r1 = new RacionalMod(3, 4);
		System.out.println(" hecho.");
		System.out.println("r1 = " + r1.toString());
		System.out.print("Creando el racional r2 de tipo RacionalNoMod (2/6) ...");
		Racional r2 = new RacionalNoMod(2, 6);
		System.out.println(" hecho.");
		System.out.println("r2 = " + r2.toString());

		System.out.print("Reduciendo el racional r1 ...");
		r1 = r1.reduce();
		System.out.println(" hecho.");
		System.out.println("r1 = " + r1.toString());
		System.out.print("Reduciendo el racional r2 ...");
		r2 = r2.reduce();
		System.out.println(" hecho.");
		System.out.println("r2 = " + r2.toString());
		
		System.out.print("Sumando r1 y r2 en r3 ...");
		Racional r3 = r1.suma(r2);
		System.out.println(" hecho.");
		System.out.println("r3 = " + r3.toString());
		
		System.out.print("Creando el racional r4 de tipo RacionalMod y copia de r2 (1/3) ...");
		Racional r4 = new RacionalNoMod(r2);
		System.out.println(" hecho.");
		System.out.println("r4: " + r4.toString());

	}

}
