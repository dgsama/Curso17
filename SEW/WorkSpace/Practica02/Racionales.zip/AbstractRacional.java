package estDatos;

/**
 * Esta clase abstracta propociona un esqueleto de implementación
 * de la interfaz {@code Racional} que facilita la obtención de un
 * tipo concreto.
 * 
 * @author Pedro Hernández
 */

public abstract class AbstractRacional implements Racional{
	
	/**
	 * Retorna el máximo común divisor de los dos 
	 * enteros que se especifican
	 * @param a el primer entero que se especifica
	 * @param b el segundo entero que se especifica
	 * @return el máximo común divisor de {@code a}
	 * y {@code b}
	 */
	protected static int mcd(int a, int b) {
		// el máximo común divisor se obtiene
		// mediante el algoritmo de Euclides
		int t, x = Math.abs(a), y = Math.abs(b);
		while (y > 0) {
			t = y;
			y = x % y;
			x = t;
		}
		return x;
	}
	
	/**
	 * Retorna el mínimo común múltiplo de los dos 
	 * enteros que se especifican
	 * @param a el primer entero que se proporciona
	 * @param b el segundo entero que se proporiona
	 * @return el mínimo común múltiplo de {@code a}
	 * y {@code b}
	 */
	protected static int mcm(int a, int b) {
		return Math.abs(a * b / mcd(a, b));
	}
	
	protected AbstractRacional() {
		
	}
	
	/**
	 * {@inheritDoc}
	 */
	public abstract int numerador();

	/**
	 * {@inheritDoc}
	 */
	public abstract int denominador();

	/**
	 * {@inheritDoc}
	 */
	public abstract Racional suma(Racional r);
	
	/**
	 * {@inheritDoc}
	 */
	public abstract Racional reduce();
	
	/**
	 * Retorna un string representando a este racional.
	 * @return el string {@code n/d}, donde {@code n}
	 * es el string que representa al numerador de este
	 * racional y {@code d} es el string que representa
	 * a su denominador.
	 */
	@Override
	public String toString() {
		Integer n = this.numerador();
		if (this.denominador() == 1) {
			return n.toString();
		}
		Integer d = this.denominador();
		return n.toString() + "/" + d.toString();
	}
		
	/**
	 * Indica si este racional es igual al especificado.
	 * En primer lugar se comprueba si el objeto especificado
	 * es este racional, en cuyo caso retorna {@code true}. En
	 * otro caso se comprueba que el objeto especificado sea
	 * un racional, de no serlo se retorna {@code false}. Por
	 * último se comprueba si ambos racionales son iguales
	 * @param obj el objeto especificado
	 * @return {@code true} si el objeto especificado es igual
	 * a este racional
	 */
	@Override	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (obj instanceof Racional) {
			Racional r = (Racional) obj;
			return this.numerador() * r.denominador() ==
				   this.denominador() * r.numerador();
		}

		return false;
	}

}
